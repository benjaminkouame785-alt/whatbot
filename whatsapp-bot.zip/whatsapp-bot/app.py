"""
WhatsApp Remote Command Bot
---------------------------
Permet d'exécuter des commandes Linux sur TON ordinateur en envoyant un
message WhatsApp, via l'API Twilio WhatsApp.

SECURITE (ne pas désactiver) :
  1. Seuls les numéros listés dans AUTHORIZED_NUMBERS peuvent envoyer des commandes.
  2. Chaque message doit commencer par le mot de passe secret (SECRET_PASSPHRASE).
  3. Une liste de commandes dangereuses est bloquée (BLOCKED_PATTERNS).
  4. Chaque commande a un timeout pour éviter qu'un process bloque le bot.
  5. Toutes les commandes et résultats sont journalisés (visibles sur le dashboard).

Lance ce fichier avec : python app.py
Puis expose-le sur internet (ngrok, ou un VPS) pour que Twilio puisse l'appeler.
"""

import os
import re
import time
import shlex
import subprocess
import threading
from collections import deque
from datetime import datetime

from flask import Flask, request, render_template, jsonify
from twilio.twiml.messaging_response import MessagingResponse
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

# ----------------------------------------------------------------------------
# CONFIGURATION (à définir dans un fichier .env, voir .env.example)
# ----------------------------------------------------------------------------

# Numéros WhatsApp autorisés à envoyer des commandes.
# Format Twilio : "whatsapp:+2250700000000"
AUTHORIZED_NUMBERS = set(
    n.strip() for n in os.environ.get("AUTHORIZED_NUMBERS", "").split(",") if n.strip()
)

# Mot de passe qui doit précéder chaque commande, ex: "SUDO123 ls -la"
SECRET_PASSPHRASE = os.environ.get("SECRET_PASSPHRASE", "")

# Dossier depuis lequel les commandes sont exécutées
WORKDIR = os.environ.get("BOT_WORKDIR", os.path.expanduser("~"))

# Timeout max (en secondes) pour une commande
COMMAND_TIMEOUT = int(os.environ.get("COMMAND_TIMEOUT", "25"))

# Longueur max d'une réponse WhatsApp (la limite réelle est ~1600 caractères)
MAX_REPLY_LEN = 1500

# Nombre d'entrées conservées dans l'historique affiché sur le dashboard
LOG_HISTORY = deque(maxlen=200)
LOG_LOCK = threading.Lock()

# Commandes / motifs interdits, même pour un expéditeur autorisé.
# Objectif : éviter de détruire la machine par erreur (fat-finger) ou abus.
BLOCKED_PATTERNS = [
    r"rm\s+-rf\s+/(\s|$)",
    r"rm\s+-rf\s+\*",
    r"mkfs",
    r":\(\)\s*\{.*:\|:.*\};",   # fork bomb
    r"dd\s+if=.*of=/dev/",
    r">\s*/dev/sd",
    r"shutdown",
    r"\breboot\b",
    r"\bpoweroff\b",
    r"\bhalt\b",
    r"chmod\s+-R\s+777\s+/",
    r"\bpasswd\b",
    r"\bmkpasswd\b",
]
BLOCKED_RE = re.compile("|".join(BLOCKED_PATTERNS), re.IGNORECASE)


def log_event(kind, sender, text):
    with LOG_LOCK:
        LOG_HISTORY.appendleft({
            "time": datetime.now().strftime("%H:%M:%S"),
            "kind": kind,       # "in" | "out" | "blocked" | "denied"
            "sender": sender,
            "text": text,
        })


def is_blocked(command: str) -> bool:
    return bool(BLOCKED_RE.search(command))


def run_command(command: str) -> str:
    """Exécute une commande shell et retourne stdout+stderr tronqués."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=WORKDIR,
            capture_output=True,
            text=True,
            timeout=COMMAND_TIMEOUT,
        )
        output = (result.stdout or "") + (result.stderr or "")
        output = output.strip() or f"(aucune sortie, code retour {result.returncode})"
    except subprocess.TimeoutExpired:
        output = f"⏱️ Timeout dépassé ({COMMAND_TIMEOUT}s), commande interrompue."
    except Exception as e:
        output = f"Erreur d'exécution : {e}"

    if len(output) > MAX_REPLY_LEN:
        output = output[:MAX_REPLY_LEN] + "\n…(sortie tronquée)"
    return output


@app.route("/webhook", methods=["POST"])
def webhook():
    sender = request.values.get("From", "")
    body = request.values.get("Body", "").strip()

    resp = MessagingResponse()

    # 1) Vérification du numéro autorisé
    if sender not in AUTHORIZED_NUMBERS:
        log_event("denied", sender, body)
        resp.message("⛔ Numéro non autorisé.")
        return str(resp)

    # 2) Vérification du mot de passe secret en préfixe
    if SECRET_PASSPHRASE:
        prefix = SECRET_PASSPHRASE + " "
        if not body.startswith(prefix):
            log_event("denied", sender, "(mot de passe manquant/incorrect)")
            resp.message("🔒 Format attendu : <mot_de_passe> <commande>")
            return str(resp)
        command = body[len(prefix):].strip()
    else:
        command = body

    if not command:
        resp.message("Commande vide.")
        return str(resp)

    log_event("in", sender, command)

    # 3) Blocage des commandes dangereuses
    if is_blocked(command):
        log_event("blocked", sender, command)
        resp.message("🚫 Commande bloquée pour raisons de sécurité.")
        return str(resp)

    # 4) Exécution
    output = run_command(command)
    log_event("out", sender, output)
    resp.message(f"$ {command}\n\n{output}")
    return str(resp)


@app.route("/")
def dashboard():
    return render_template("dashboard.html")


@app.route("/api/logs")
def api_logs():
    with LOG_LOCK:
        return jsonify(list(LOG_HISTORY))


@app.route("/health")
def health():
    return jsonify({"status": "ok", "time": time.time()})


if __name__ == "__main__":
    if not AUTHORIZED_NUMBERS:
        print("⚠️  Aucun numéro dans AUTHORIZED_NUMBERS : personne ne pourra utiliser le bot.")
    if not SECRET_PASSPHRASE:
        print("⚠️  Aucun SECRET_PASSPHRASE défini : c'est fortement déconseillé.")
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
