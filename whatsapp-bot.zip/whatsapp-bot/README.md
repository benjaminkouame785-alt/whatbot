# WA-SHELL — Bot WhatsApp pour exécuter des commandes Linux à distance

Envoie des commandes depuis WhatsApp (téléphone **ou** ordinateur), elles
s'exécutent sur ta machine, et la réponse revient dans la conversation
WhatsApp. Un dashboard web style "hacker" (pluie Matrix + logs animés)
affiche l'historique en direct.

⚠️ **C'est un outil d'accès à distance à ta machine.** Si mal configuré,
n'importe qui pourrait exécuter des commandes chez toi. Respecte bien les
étapes de sécurité ci-dessous.

## 1. Installation

```bash
cd whatsapp-bot
python3 -m venv venv
source venv/bin/activate        # Windows : venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

Édite `.env` :
- `AUTHORIZED_NUMBERS` → **uniquement** ton propre numéro WhatsApp
- `SECRET_PASSPHRASE` → un mot de passe long et difficile à deviner
- `BOT_WORKDIR` → le dossier où tu veux que les commandes s'exécutent

## 2. Créer un compte Twilio (gratuit pour tester)

1. Crée un compte sur https://www.twilio.com/
2. Active le **WhatsApp Sandbox** : Console → Messaging → Try it out → Send a WhatsApp message
3. Depuis ton téléphone, envoie le code `join <mot-affiché>` au numéro Twilio sandbox fourni, pour lier ton numéro au bot
4. Note le numéro WhatsApp Twilio (tu ne le configures pas dans `.env`, c'est le `AUTHORIZED_NUMBERS` qui doit contenir **ton** numéro à toi)

## 3. Lancer le bot

```bash
python app.py
```

Le dashboard est visible sur `http://localhost:5000/`
Le webhook à donner à Twilio est `http://<ton-adresse-publique>/webhook`

## 4. Exposer le bot à internet (test local)

Twilio doit pouvoir atteindre ton serveur depuis l'extérieur. Pour tester en local, utilise `ngrok` :

```bash
ngrok http 5000
```

Copie l'URL `https://xxxx.ngrok.io/webhook` et colle-la dans :
Twilio Console → WhatsApp Sandbox Settings → "When a message comes in"

## 5. Utilisation

Depuis WhatsApp (téléphone ou WhatsApp Web sur ordinateur), envoie :

```
MonMotDePasse123 ls -la
```

```
MonMotDePasse123 df -h
```

Le bot répond avec la sortie de la commande, et chaque échange apparaît
en direct sur le dashboard (`http://localhost:5000/`).

## Sécurité — ce qui est déjà en place

- **Whitelist de numéros** : seuls les numéros dans `AUTHORIZED_NUMBERS` sont acceptés.
- **Mot de passe obligatoire** en préfixe de chaque message.
- **Liste de blocage** : `rm -rf /`, `mkfs`, fork bombs, `shutdown`, `passwd`, etc. sont refusées même pour un expéditeur autorisé.
- **Timeout** sur chaque commande (25s par défaut) pour éviter un process bloqué.
- **Logs** de toutes les tentatives (acceptées, bloquées, refusées).

## Sécurité — ce que TU dois faire en plus

- Ne déploie jamais ce bot sans `.env` configuré (sans mot de passe = n'importe qui peut l'utiliser).
- Si tu le mets en production (pas juste pour tester), héberge-le sur un petit VPS avec HTTPS plutôt que de laisser ton PC personnel exposé en permanence.
- Ne commit jamais `.env` dans un dépôt Git public.
- Change `SECRET_PASSPHRASE` régulièrement.
- Passe en WhatsApp Business API officielle (au lieu du Sandbox Twilio) si tu veux un usage durable : le sandbox expire et est limité à des numéros pré-validés.

## Pour aller plus loin

- Ajouter une 2ème étape de confirmation ("tape OUI pour confirmer") avant les commandes destructrices non bloquées.
- Restreindre encore plus avec une **whitelist de commandes autorisées** plutôt qu'une blacklist (plus sûr, mais moins flexible).
- Stocker les logs dans SQLite au lieu de la mémoire, pour garder l'historique après redémarrage.
